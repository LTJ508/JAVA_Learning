import java.util.Scanner;

public class Task02 {

	public static void main(String[] args) {
		char op;
		int a, b, res;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter operator: ");
		op = scan.next().charAt(0);
		
		System.out.print("Enter 1st Operand: ");
		a = scan.nextInt();
		System.out.print("Enter 2nd Operand: ");
		b = scan.nextInt();
		
		switch(op) {
		case '+':
			res = a + b;
			System.out.println("Result is: " + res);
			break;
		case '-':
			res = a - b;
			System.out.println("Result is: " + res);
			break;
		case '*':
			res = a * b;
			System.out.println("Result is: " + res);
			break;
		case '/':
			res = a / b;
			System.out.println("Result is: " + res);
			break;
		default:
			System.out.println("Invalid Operator");
		}
	}

}
