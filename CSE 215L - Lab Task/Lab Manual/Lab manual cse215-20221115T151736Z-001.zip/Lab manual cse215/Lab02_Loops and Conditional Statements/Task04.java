import java.util.Scanner;

public class Task04 {

	public static void main(String[] args) {
		int a, b, c, D;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the coefficients: ");
		System.out.print("Enter a: ");
		a = scan.nextInt();
		System.out.print("Enter b: ");
		b = scan.nextInt();
		System.out.print("Enter c: ");
		c = scan.nextInt();

		D = (b * b) - (4 * a * c); // -25
		
		if(D == 0) {
			//Both roots are same (real)
		}
		else if(D > 0) {
			// Two real roots
		}
		else {
			double firstPart = (-b / (2.0 * a));
			double secondPart = (Math.sqrt(-D) / (2.0 * a));
			String r1 = firstPart + " + " + secondPart + "i";
			String r2 = firstPart + " - " + secondPart + "i";
			
			System.out.println("Root1: " + r1);
			System.out.println("Root2: " + r2);
		}
	}

}
