import java.util.Scanner;

public class Task01 {

	public static void main(String[] args) {
		int N, i = 1;
		int num, sum = 0;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter N: ");
		N = scan.nextInt();
		
		while(i <= N) {
			System.out.print("Enter a number: ");
			num = scan.nextInt();
			sum = sum + num;
			i++;
		}
		
		System.out.println("Sum: " + sum);
	}

}
