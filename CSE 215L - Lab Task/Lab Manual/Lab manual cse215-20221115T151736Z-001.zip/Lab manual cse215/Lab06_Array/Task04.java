import java.util.Scanner;

public class Task04 {

	public static void main(String[] args) {
		int m, n;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter rows: ");
		m = scan.nextInt();
		System.out.print("Enter columns: ");
		n = scan.nextInt();
		
		int[][] A = new int[m][n];
		int[][] B = new int[n][m];
		
		System.out.println("Enter Matrix Elements: ");
		for(int i = 0; i < m; i++) {
			for(int j = 0; j < n; j++) {
				A[i][j] = scan.nextInt();
			}
		}
		
		System.out.println();
		
		System.out.println("A: ");
		for(int i = 0; i < m; i++) {
			for(int j = 0; j < n; j++) {
				System.out.printf("%4d", A[i][j]);
			}
			System.out.println();
		}
		
		for(int i = 0; i < n; i++) {
			for(int j = 0; j < m; j++) {
				B[i][j] = A[j][i];
			}
		}
		
		System.out.println("B: ");
		for(int i = 0; i < n; i++) {
			for(int j = 0; j < m; j++) {
				System.out.printf("%4d", B[i][j]);
			}
			System.out.println();
		}
	}

}

