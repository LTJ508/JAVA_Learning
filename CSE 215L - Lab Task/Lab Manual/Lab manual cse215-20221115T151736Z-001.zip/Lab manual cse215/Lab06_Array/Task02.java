import java.util.Scanner;

public class Task02 {

	public static void main(String[] args) {
		int[][] ara = new int[3][3];
		Scanner scan = new Scanner(System.in);
		int sum = 0;
		
		System.out.println("Enter Array Elements: ");
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				System.out.print("ara[" + i + "][" + j + "] = ");
				ara[i][j] = scan.nextInt();
			}
		}
		
		System.out.println();
		
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				System.out.print(ara[i][j] + "  ");
			}
			System.out.println();
		}
		
		for(int i = 0; i < 3; i++) {
			sum = sum + ara[i][i];
		}
			
		System.out.println("Sum: " +sum);

	}

}
