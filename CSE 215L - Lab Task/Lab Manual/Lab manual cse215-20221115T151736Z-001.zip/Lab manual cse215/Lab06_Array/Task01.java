import java.util.Scanner;

public class Task01 {

	public static void main(String[] args) {
		int[] ara = new int[10];
		int num;
		boolean flag = false;
		Scanner scan = new Scanner(System.in);
		
		for(int i = 0; i < 10; i++) {
			System.out.print("ara[" + i + "] = ");
			ara[i] = scan.nextInt();
		}
		
		System.out.print("Enter a number: ");
		num = scan.nextInt();
		
		for(int i = 0; i < 10; i++) {
			if(ara[i] == num) {
				flag = true;
				break;
			}
		}
		
		if(flag) {
			System.out.println("Found");
		}
		else {
			System.out.println("Not Found");
		}
		
	}

}
