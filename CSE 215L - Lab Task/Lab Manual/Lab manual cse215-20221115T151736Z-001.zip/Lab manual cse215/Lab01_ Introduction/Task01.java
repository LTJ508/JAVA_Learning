
public class Task01 {

	public static void main(String[] args) {
		System.out.println("Name: Md. Mustafizur Rahman");
		System.out.println("Age: 28");
		System.out.println("Department: ECE");
	}
}
