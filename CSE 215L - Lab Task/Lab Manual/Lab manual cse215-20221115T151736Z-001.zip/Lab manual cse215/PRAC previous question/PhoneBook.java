

public class PhoneBook {
	private Contact[] contacts;
	private int numOfContacts;
	private int index = 0;
	
	public PhoneBook(int size) {
		this.contacts = new Contact[size];
		this.numOfContacts = 0;
	}
	
	public boolean isEmpty() {
		if(this.numOfContacts == 0) return true;
		else return false;
	}
	
	public boolean isFull() {
		if(this.numOfContacts == contacts.length) return true;
		else return false;
	}
	
	public boolean addContact(Contact contact) {
		if(!isFull()) {
			contacts[index] = contact;
			index++;
			this.numOfContacts++;
			return true;
		}else return false;
	}
	
	public int getSize() {
		return contacts.length;
	}
	
	public void viewAllContacts() {
		for (int i = 0; i < this.numOfContacts; i++) {
			System.out.println(contacts[i].toString());
		}
	}
	
	public void viewEmergencyContacts() {
		for (int i = 0; i < this.numOfContacts; i++) {
			if(contacts[i].isEmergencyContact())
				System.out.println(contacts[i].toString());
		}
	}
	
	public String searchContact(String name) {
		for (int i = 0; i < this.numOfContacts; i++) {
			if(contacts[i].getName().equals(name)) {
				return contacts[i].toString();
			}
		}
		
		return "Not found!";

	}
	
	public void delete(String name) {
		int index = -1;
		for (int i = 0; i < this.numOfContacts; i++) {
			if(contacts[i].getName().equals(name)) {
				index = i;
				break;
			}
		}
		
		for (int i = index; i < this.numOfContacts-1; i++) {
			contacts[i] = contacts[i+1];
		}
		
		this.numOfContacts--;
		
	}
	
	public void deleteAll() {
		this.contacts = null;
	}

}