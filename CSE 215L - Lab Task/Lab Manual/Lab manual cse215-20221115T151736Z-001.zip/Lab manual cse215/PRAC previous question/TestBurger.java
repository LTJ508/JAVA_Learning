
public class TestBurger {

	public static void main(String[] args) {
		Burger b1 = new Burger("Large", 2, 2, 1 );
		System.out.println(b1.getDescription());

	}

}
