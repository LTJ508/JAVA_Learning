
public class Burger {
	private String bunSize;
	private int patty;
	private int cheese;
	private int pastrami;
	
	public Burger() {
		bunSize = "null";
		patty = 0;
		cheese = 0;
		pastrami = 0;
	}
	public Burger(String bunSize, int patty, int cheese, int pastrami) {
		this.bunSize = bunSize;
		this.patty = patty;
		this.cheese = cheese;
		this.pastrami = pastrami;
	}
	
	public String getBunSize() {
		return bunSize;
	}
	
	public int getPatty() {
		return patty;
	}
	
	public int getCheese() {
		return cheese;		
	}
	
	public int getPastrami() {
		return pastrami;
	}
	
	public void setBunSize(String bunSize) {
		this.bunSize = bunSize;
		
	}
	
	public void setPatty(int patty) {
		this.patty = patty;
	}
	
	public void setCheese(int cheese) {
		this.cheese = cheese;	
	}
	
	public void setPastrami(int pastrami) {
		this.pastrami = pastrami;
	}
	

	public double calcCost()
		{
			double bun=0,total;
	        if(bunSize.equalsIgnoreCase("Small"))
	        bun = 3.0;
	        if(bunSize.equalsIgnoreCase("Medium"))
	        bun = 4.0;
	        if(bunSize.equalsIgnoreCase("Large"))
	        bun = 5.0;
	        total = bun+(2*cheese)+(3*pastrami)+(10*patty);
	        return total;
		}
	
	
	public String getDescription() {
		return "Burger Bun Size: " + getBunSize() + "\nNo of Patties: "+getPatty()+ "\nCheese Slices: "+getCheese()+ "\nPastrami Slices: "+getPastrami()+ "\nBurger Cost: "+calcCost();
	}
}
