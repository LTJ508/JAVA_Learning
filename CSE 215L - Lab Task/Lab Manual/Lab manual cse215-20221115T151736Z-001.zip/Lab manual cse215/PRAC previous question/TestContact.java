
public class TestContact {

	public static void main(String[] args) {
		System.out.println("PhoneBook");
		Contact c1 = new Contact("A", "017", false);
		Contact c2 = new Contact("B", "016", true);
		Contact c3 = new Contact("C", "018", false);

		PhoneBook pBook = new PhoneBook(3);
		pBook.addContact(c1);
		pBook.addContact(c2);
		pBook.addContact(c3);
		pBook.viewAllContacts();
		
		//pBook.viewEmergencyContacts();
		//System.out.println(pBook.searchContact("B"));
		
		pBook.delete("A");
		pBook.viewAllContacts();

	}

	public static void isEmpty(boolean isEmpty) {
		if (isEmpty)
			System.out.println("Empty");
		else
			System.out.println("Not Empty");
	}

	public static void isFull(boolean isFull) {
		if (isFull)
			System.out.println("Full");
		else
			System.out.println("Not Full");
	}

}