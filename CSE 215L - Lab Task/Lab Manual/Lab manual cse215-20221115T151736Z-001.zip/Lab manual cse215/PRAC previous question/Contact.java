
public class Contact {
	private String name;
	private String number;
	private boolean emargencyContact;
	
	public Contact() {
		name = "null";
		number = "null";
		emargencyContact = false;
	}
	public Contact(String name, String number, boolean emargencyContact) {
		this.name = name;
		this.number = number;
		this.emargencyContact = emargencyContact;
	}
	
	public String getName() {
		return name;
	}
	
	public String getNumber() {
		return number;
	}
	
	public boolean isEmergencyContact() {
		return emargencyContact;
	}
	
	public boolean getEmargencyNumber() {
		return	emargencyContact;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setNumber(String number) {
		this.number = number;
	}
	
	public void setEmargencyNumber(boolean emargencyContact) {
		this.emargencyContact = emargencyContact;
	}
	
	public String toString() {
		return "Name: "+getNumber()+ "\nNumber: "+getNumber()+ "\nEmargency Contact: " +getEmargencyNumber() ;
	}
}
