
public class Weight implements Comparable<Weight> {
	private int pounds;
	private int ounces;

	public Weight() {

	}

	public Weight(int pounds, int ounces) {
		this.pounds = pounds;
		this.ounces = ounces;
	}

	public int getPounds() {
		return pounds;
	}

	public int getOunces() {
		return ounces;
	}

	public void setPounds(int pounds) {
		this.pounds = pounds;
	}

	public void setOunces(int ounces) {
		this.ounces = ounces;
	}

	@Override
	public String toString() {
		return "Weight [pounds=" + pounds + ", ounces=" + ounces + "]";
	}

	@Override
	public int compareTo(Weight w) {
		if (this.pounds > w.pounds && this.ounces > w.ounces)
			return 1;
		else if (this.pounds == w.pounds && this.ounces == w.ounces)
			return 0;
		else
			return -1;
	}

	public Weight add(Weight m) {
		Weight obj = new Weight();
		obj.pounds = this.pounds + m.pounds;
		obj.ounces = this.ounces + m.ounces;
		return obj;
	}

}
