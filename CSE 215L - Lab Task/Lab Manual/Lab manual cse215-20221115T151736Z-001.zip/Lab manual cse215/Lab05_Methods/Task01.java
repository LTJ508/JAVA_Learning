import java.util.Scanner;

public class Task01 {

	public static int isPerfect(int N) {
		int sum = 0;
		
		for(int i = 1; i <= (N / 2); i++) {
			if(N % i == 0) {
				sum = sum + i;
			}
		}
		
		if(sum == N) {
			return 1;
		}
		
		return 0;
	}
	
	public static void main(String[] args) {
		int n;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter n: ");
		n = scan.nextInt();
		
		for(int i = 2; i <=n; i++) {
			if(isPerfect(i) == 1) {
				System.out.print(i + "  ");
			}
		}
	}

}
