import java.util.Scanner;

public class Task02 {

	public static int sumOfDigits(int N) {
		int rem, sum = 0;
	
		while(N != 0) {
			rem = N % 10;
			sum = sum + rem;
			N = N / 10;
		}
		
		return sum;
	}
	
	public static void main(String[] args) {
		int num;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter a number: ");
		num = scan.nextInt();
		
		int sum = sumOfDigits(num);
		
		System.out.println("Sum: " + sum);
	}

}
