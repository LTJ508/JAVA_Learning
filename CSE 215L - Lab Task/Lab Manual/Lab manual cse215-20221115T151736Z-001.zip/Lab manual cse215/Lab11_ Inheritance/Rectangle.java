
public class Rectangle extends GeometricObject {
	private double width;
	private double height;
	
	public Rectangle() {
		super();
		width = 0.0;
		height = 0.0;
	}
	public Rectangle(double width, double height) {
		super();
		this.width = width;
		this.height = height;
	}
	public Rectangle(double width, double height, String color, boolean filled) {
		super();
		this.width = width;
		this.height = height;		
	}
	public double getWidth() {
		return width;
	}
	public double getHeight() {
		return height;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public double getPerimeter() {
		return 2 * width * height;
		
	}
	public double getDiameter() {
		return Math.sqrt((width*width) + (height*height));
		
	}
	public double getArea() {
		return width * height;
		
	}
	public void printRectangle() {
		System.out.println("Rectangle[Width:"+width+ ",Height :"+height+ ",Perimeter:" +getPerimeter()+ ",Diameter: "+getDiameter()+",Area: "+getArea());
	}
}
