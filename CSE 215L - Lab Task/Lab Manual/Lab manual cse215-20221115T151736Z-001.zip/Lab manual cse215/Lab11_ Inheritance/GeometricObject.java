
public class GeometricObject {
	private String color;
	private boolean filled;
	
	public GeometricObject() {
		color = "red";
		filled = false;
	}
	public GeometricObject(String color,boolean filled) {
		this.color = color;
		this.filled = filled;
	}
	public String getColor() {
		return color;
	}
	public boolean getFilled() {
		return filled;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public void setFelled(boolean filled) {
		this.filled = filled;
	}

	public String toString() {
		return "Geometric Object [color : " + color + ", filled :" +filled +"]";
	}
}
