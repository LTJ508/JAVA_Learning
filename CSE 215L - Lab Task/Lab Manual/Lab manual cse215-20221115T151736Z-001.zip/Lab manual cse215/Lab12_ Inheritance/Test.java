
public class Test {

	public static void main(String[] args) {
		 PartTimeEmployee partTimeEmployee = new PartTimeEmployee("A", 22, "Dhk", "CSE", "Eng.", 10, 100);
	        System.out.println(partTimeEmployee);

	        System.out.println();

	        FullTimeEmployee fullTimeEmployee = new FullTimeEmployee("B", 20, "Ctg", "CSE", "Web", 25000, 10);

	        System.out.println(fullTimeEmployee);


	    }


}


