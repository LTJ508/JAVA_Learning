import java.util.Scanner;

public class Task03 {

	public static void main(String[] args) {
		int n;
		double term, sum = 0;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter n: ");
		n = scan.nextInt();

		for(int i = 1; i <= n; i++) {
			term = 1.0 / (i * i);
			if(i % 2 == 1) {
				sum = sum + term;
			}
			else {
				sum = sum - term;
			}
		}
		
		System.out.printf("Sum: %.2f\n", sum);
	}

}
