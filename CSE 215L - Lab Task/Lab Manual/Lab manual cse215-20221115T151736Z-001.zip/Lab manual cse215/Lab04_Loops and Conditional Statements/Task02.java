import java.util.Scanner;

public class Task02 {

	public static void main(String[] args) {
		int N;
		boolean flag = true;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter N: ");
		N = scan.nextInt();
		
		if(N == 0 || N == 1) {
			flag = false;
		}
		else {
			for(int i = 2; i < N; i++) {
				if(N % i == 0) {
					flag = false;
					break;
				}
			}
		}
		
		if(flag) {
			System.out.println(N + " is Prime");
		}
		else {
			System.out.println(N + " is not Prime");
		}
	}

}
