import java.util.Scanner;

public class Task01 {

	public static void main(String[] args) {
		int N;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter N: ");
		N = scan.nextInt();
		
		int rem = N % 2;
		
		switch(rem) {
		case 0: 
			System.out.println(N + " is Even");
			break;
		case 1:
			System.out.println(N + " is Odd");
			break;
		}
	}

}
