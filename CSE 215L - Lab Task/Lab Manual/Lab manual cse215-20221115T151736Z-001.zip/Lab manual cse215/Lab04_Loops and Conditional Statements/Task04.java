import java.util.Scanner;

public class Task04 {

	public static void main(String[] args) {
		int N;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter N: ");
		N = scan.nextInt();
		
		for(int i = 1; i <= N; i++) {
			for(int j = 1; j <= i; j++) {
				System.out.print(j);
			}
			System.out.println();
		}
	}

}
