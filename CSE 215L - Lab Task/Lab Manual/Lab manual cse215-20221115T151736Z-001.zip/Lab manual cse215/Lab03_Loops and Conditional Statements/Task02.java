import java.util.Scanner;

public class Task02 {

	public static void main(String[] args) {
		int min = 5, max = 20;
		int N;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("How many random numbers: ");
		N = scan.nextInt();
		
		for(int i = 1; i <= N; i++) {
			int n = (int)(min + (Math.random() * (max - min + 1)));
			System.out.print(n + "  ");
		}
	}

}
