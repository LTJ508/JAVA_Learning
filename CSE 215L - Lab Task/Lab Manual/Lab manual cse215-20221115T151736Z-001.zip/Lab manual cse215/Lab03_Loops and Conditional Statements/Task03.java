import java.util.Scanner;

public class Task03 {

	public static void main(String[] args) {
		char ch;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter a character: ");
		ch = scan.next().charAt(0);
		
		if((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')) {
			System.out.println("It is a letter");
		}
		else if(ch >= '0' && ch <= '9') {
			System.out.println("It is a digit");
		}
		else {
			System.out.println("It is a symbol");
		}
	}

}
