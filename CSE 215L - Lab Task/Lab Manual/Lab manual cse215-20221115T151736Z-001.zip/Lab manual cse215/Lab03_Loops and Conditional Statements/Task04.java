import java.util.Scanner;

public class Task04 {

	public static void main(String[] args) {
		String city1, city2;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter first city: ");
		city1 = scan.nextLine();
		System.out.print("Enter second city: ");
		city2 = scan.nextLine();
		
		System.out.print("The cities in alphabetical orders are: ");
		if(city1.compareTo(city2) < 0) {
			System.out.print(city1 + " and " + city2);
		}
		else if(city1.compareTo(city2) > 0) {
			System.out.print(city2 + " and " + city1);
		}
		else {
			System.out.print(city1 + " and " + city2);
		}
	}

}
