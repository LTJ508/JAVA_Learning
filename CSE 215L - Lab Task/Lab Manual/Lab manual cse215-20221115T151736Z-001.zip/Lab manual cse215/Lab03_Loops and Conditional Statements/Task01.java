import java.util.Scanner;

public class Task01 {

	public static void main(String[] args) {
		int a, b;
		int min, GCD = 1;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter a: ");
		a = scan.nextInt();
		System.out.print("Enter b: ");
		b = scan.nextInt();

		min = a < b ? a : b;
		
		for(int i = 1; i <= min; i++) {
			if(a % i == 0 && b % i == 0) {
				GCD = i;
			}
		}
		
		System.out.println("GCD: " + GCD);
	}

}
