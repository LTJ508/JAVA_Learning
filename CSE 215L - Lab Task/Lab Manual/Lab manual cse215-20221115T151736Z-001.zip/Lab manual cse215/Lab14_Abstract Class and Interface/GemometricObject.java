package LAB15;

public interface GemometricObject {

	public double getPerimeter();
	public double getArea();
	
}
