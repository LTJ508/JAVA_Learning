package LAB15;

public class Cricle implements GemometricObject{

	protected double radius;
	public Cricle(double radius)
	{
		this.radius=radius;
	}
	@Override
	public double getPerimeter() {
		
		return 2*Math.PI*radius;
	}
	@Override
	public double getArea() {
		
		return Math.PI*radius*radius;
	}


	

}
