package LAB15;

public class Driver {

	public static void main(String[] args) {
		
		ResizableCircle rc=new ResizableCircle(10);
		
		System.out.println("Area: "+rc.getArea());
		System.out.println("Perimeter: "+rc.getPerimeter());
		
		rc.resize(50);
		
		System.out.println("After resizing 50% ");
		System.out.println("Area: "+rc.getArea());
		System.out.println("Perimeter: "+rc.getPerimeter());
		

	}

}
